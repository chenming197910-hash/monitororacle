import re
import xml.etree.ElementTree as ET


# Boundary:
# monitoring collectors below must stay hard-coded SELECT-only.
# run_remote_ddl() is only for the independent DDL publish center after password and double confirmation.
# Do not add parameter changes, jobs, helper objects, or hidden writes to the monitoring collection path.
DBLINK_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_$#.-]+$")


def dblink_name(name):
    value = str(name or "").strip()
    if not value or not DBLINK_NAME_PATTERN.match(value):
        raise ValueError(f"DBLink 名称不安全或为空: {value}")
    return value


def fetch_public_dblinks(db):
    with db.cursor() as cur:
        cur.execute(
            """
            select db_link, username, host
            from dba_db_links
            where owner = 'PUBLIC'
              and db_link not like 'MSYNC%'
              and db_link not like 'ASM%'
            order by db_link
            """
        )
        return [{"db_link": row[0], "username": row[1], "host_alias": row[2]} for row in cur.fetchall()]


def fetch_public_asm_dblinks(db):
    with db.cursor() as cur:
        cur.execute(
            """
            select db_link, username, host
            from dba_db_links
            where owner = 'PUBLIC'
              and db_link like 'ASM%'
            order by db_link
            """
        )
        return [{"db_link": row[0], "username": row[1], "host_alias": row[2]} for row in cur.fetchall()]


def query_dicts(db, sql, params=None):
    with db.cursor() as cur:
        cur.execute(sql, params or {})
        columns = [col[0].lower() for col in cur.description]
        return [dict(zip(columns, row)) for row in cur.fetchall()]


def query_one(db, sql, params=None):
    rows = query_dicts(db, sql, params)
    return rows[0] if rows else {}


def run_remote_select(db, db_link, sql_text, max_rows=100):
    link = dblink_name(db_link)
    limited_sql = f"select * from ({sql_text}) where rownum <= {int(max_rows)}"
    with db.cursor() as cur:
        cur.execute(
            f"select dbms_xmlgen.getxmltype@{link}(:sql_text).getclobval() from dual",
            {"sql_text": limited_sql},
        )
        value = cur.fetchone()[0]
    xml_text = value.read() if hasattr(value, "read") else str(value or "")
    return parse_dbms_xmlgen_rows(xml_text)


def parse_dbms_xmlgen_rows(xml_text):
    if not xml_text:
        return []
    root = ET.fromstring(xml_text)
    rows = []
    for row_node in root.findall(".//ROW"):
        row = {}
        for child in list(row_node):
            row[child.tag.lower()] = child.text
        rows.append(row)
    return rows


def run_remote_ddl(db, db_link, ddl_text):
    link = dblink_name(db_link)
    with db.cursor() as cur:
        cur.execute(f"begin dbms_utility.exec_ddl_statement@{link}(:ddl_text); end;", {"ddl_text": ddl_text})
    return True


def collect_oracle_database(db, db_link):
    link = dblink_name(db_link)
    return query_one(
        db,
        f"""
        select d.name as db_name,
               d.dbid,
               d.platform_name,
               d.database_role,
               d.open_mode,
               i.host_name,
               i.version,
               p.value as max_processes,
               pr.current_processes
        from v$database@{link} d
        cross join v$instance@{link} i
        left join (
            select value
            from v$parameter@{link}
            where name = 'processes'
        ) p on 1 = 1
        left join (
            select count(*) as current_processes
            from v$process@{link}
        ) pr on 1 = 1
        """,
    )


def collect_tablespaces(db, db_link):
    link = dblink_name(db_link)
    return query_dicts(
        db,
        f"""
        select m.tablespace_name,
               round(m.used_space * t.block_size / 1024 / 1024 / 1024, 2) as used_gb,
               round(m.tablespace_size * t.block_size / 1024 / 1024 / 1024, 2) as total_gb,
               round(m.used_percent, 2) as used_pct
        from dba_tablespace_usage_metrics@{link} m
        join dba_tablespaces@{link} t on t.tablespace_name = m.tablespace_name
        order by m.used_percent desc
        """,
    )


def collect_database_size(db, db_link):
    link = dblink_name(db_link)
    return query_one(
        db,
        f"""
        select round(nvl(sum(bytes), 0) / 1024 / 1024 / 1024, 2) as data_gb
        from dba_segments@{link}
        """,
    )


def collect_archivelog(db, db_link):
    link = dblink_name(db_link)
    return query_one(
        db,
        f"""
        select count(*) as archive_count,
               round(nvl(sum(blocks * block_size), 0) / 1024 / 1024 / 1024, 2) as archive_gb,
               min(first_time) as begin_time,
               max(next_time) as end_time
        from v$archived_log@{link}
        where first_time >= trunc(sysdate) - 1
          and first_time < trunc(sysdate)
          and dest_id = 1
        """,
    )


def collect_top_objects(db, db_link):
    link = dblink_name(db_link)
    return query_dicts(
        db,
        f"""
        select s.owner,
               s.segment_name as object_name,
               s.segment_type as object_type,
               round(s.bytes / 1024 / 1024 / 1024, 2) as total_gb,
               nvl(t.num_rows, 0) as table_rows
        from (
            select owner, segment_name, segment_type, sum(bytes) as bytes
            from dba_segments@{link}
            where owner not in ('SYS', 'SYSTEM', 'SYSMAN', 'DBSNMP', 'OUTLN', 'XDB')
            group by owner, segment_name, segment_type
            order by sum(bytes) desc
            fetch first 10 rows only
        ) s
        left join dba_tables@{link} t
          on t.owner = s.owner and t.table_name = s.segment_name
        order by s.bytes desc
        """,
    )


def collect_asm_diskgroups(db, db_link):
    link = dblink_name(db_link)
    return query_dicts(
        db,
        f"""
        select name as diskgroup_name,
               round(total_mb / 1024, 2) as total_gb,
               round(free_mb / 1024, 2) as free_gb,
               round((total_mb - free_mb) / 1024, 2) as used_gb,
               round(case when total_mb > 0 then (total_mb - free_mb) * 100 / total_mb else 0 end, 2) as used_pct
        from v$asm_diskgroup@{link}
        order by name
        """,
    )


def fetch_sql_awr(db, db_link, sql_id, days=183):
    link = dblink_name(db_link)
    stats = query_dicts(
        db,
        f"""
        select sn.end_interval_time as snap_time,
               st.sql_id,
               st.plan_hash_value,
               sum(st.executions_delta) as executions,
               round(sum(st.elapsed_time_delta) / 1000000, 2) as elapsed_sec,
               round(sum(st.cpu_time_delta) / 1000000, 2) as cpu_sec,
               sum(st.buffer_gets_delta) as buffer_gets,
               sum(st.disk_reads_delta) as disk_reads,
               sum(st.rows_processed_delta) as rows_processed
        from dba_hist_sqlstat@{link} st
        join dba_hist_snapshot@{link} sn
          on sn.snap_id = st.snap_id
         and sn.dbid = st.dbid
         and sn.instance_number = st.instance_number
        where st.sql_id = :sql_id
          and sn.end_interval_time >= sysdate - :days
        group by sn.end_interval_time, st.sql_id, st.plan_hash_value
        order by sn.end_interval_time
        """,
        {"sql_id": sql_id, "days": days},
    )
    plans = query_dicts(
        db,
        f"""
        select sql_id,
               plan_hash_value,
               id as plan_line_id,
               parent_id,
               depth,
               operation,
               options,
               object_owner,
               object_name,
               cardinality,
               cost,
               position,
               access_predicates,
               filter_predicates
        from dba_hist_sql_plan@{link}
        where sql_id = :sql_id
        order by plan_hash_value, id
        """,
        {"sql_id": sql_id},
    )
    return {"stats": stats, "plans": plans}
